package com.example.devour2d

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var gameView: WebView

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 19, 28)
        window.navigationBarColor = Color.rgb(16, 19, 28)
        window.decorView.systemUiVisibility = 0
        gameView = WebView(this)
        gameView.setBackgroundColor(Color.rgb(16, 19, 28))
        gameView.settings.javaScriptEnabled = true
        gameView.settings.domStorageEnabled = true
        gameView.settings.allowFileAccess = true
        gameView.settings.allowContentAccess = false
        gameView.webViewClient = WebViewClient()
        gameView.webChromeClient = WebChromeClient()
        gameView.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(gameView)
        gameView.loadUrl("file:///android_asset/game.html")
    }

    override fun onPause() {
        if (::gameView.isInitialized) gameView.evaluateJavascript(
            "localStorage.setItem('devour2d-save', JSON.stringify((()=>{try{return JSON.parse(localStorage.getItem('devour2d-save'))||{}}catch(e){return {}}})()))", null
        )
        super.onPause()
    }

    override fun onBackPressed() {
        if (::gameView.isInitialized) {
            gameView.evaluateJavascript("localStorage.setItem('devour2d-save', JSON.stringify(JSON.parse(localStorage.getItem('devour2d-save')||'{}')))", null)
        }
        super.onBackPressed()
    }
}
