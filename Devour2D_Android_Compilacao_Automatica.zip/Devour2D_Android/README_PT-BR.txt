DEVOUR 2D OFFLINE — PROJETO ANDROID

Este é um projeto-fonte Android Studio que empacota um jogo 2D independente em um WebView local.
O jogo não solicita permissão de internet e usa armazenamento local do WebView para salvar progresso.

COMO GERAR O APK
1. Extraia o ZIP em um computador.
2. Instale o Android Studio (com Android SDK 35) e abra a pasta Devour2D_Android.
3. Aguarde a sincronização do Gradle.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste será gerado em app/build/outputs/apk/debug/app-debug.apk.
6. Copie esse APK para o celular Android e instale. Se solicitado, autorize a instalação dessa fonte.

NOTAS
- minSdk 24 (Android 7.0 ou superior).
- O projeto é uma recriação independente simplificada, não uma conversão nem modificação do APK original.
- O jogo salva periodicamente e calcula recompensas offline ao reabrir (até 8 horas, estimativa simples).
- Para distribuir publicamente, crie uma chave de assinatura própria e revise nome/ícone.
